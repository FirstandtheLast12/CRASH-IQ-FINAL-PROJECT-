extends Node

signal pathway_updated(amplitudes: Dictionary)

var _cycle_amplitudes: Array[Dictionary] = []

var _amplitude_sums: Dictionary = {
	"EXPEDIENT": 0.0,
	"ANALYTICAL": 0.0,
	"VALUE_DRIVEN": 0.0,
	"RULING_GUIDE": 0.0,
	"REVISIONIST": 0.0,
	"GLOBAL": 0.0
}

var _current: Dictionary = {}
var _prev_etf_traded: String = ""

func _ready() -> void:
	SimulationManager.trading_opened.connect(_on_trading_opened)
	SimulationManager.trade_confirmed.connect(_on_trade_confirmed)

func record_info_panel_opened(ticker: String) -> void:
	if _current.is_empty():
		return
	if not _current["info_panel_opened"]:
		_current["info_panel_opened"] = true
		_current["first_action"] = "INFO"
	_current["info_panel_switches"] += 1
	if ticker not in _current["etfs_checked"]:
		_current["etfs_checked"].append(ticker)

func record_headline_viewed() -> void:
	if _current.is_empty():
		return
	_current["info_panel_switches"] += 1
	_current["headline_reread"] = true

func get_final_amplitudes() -> Dictionary:
	var cycle_count: int = _cycle_amplitudes.size()
	if cycle_count == 0:
		return _amplitude_sums.duplicate()

	var result: Dictionary = {}
	for key in _amplitude_sums:
		result[key] = _amplitude_sums[key] / float(cycle_count)
	return result

func get_dominant_pathway() -> String:
	var amplitudes: Dictionary = get_final_amplitudes()
	var best_key: String = "EXPEDIENT"
	var best_value: float = -1.0
	for key in amplitudes:
		if amplitudes[key] > best_value:
			best_value = amplitudes[key]
			best_key = key
	return best_key

func get_learning_delta() -> float:
	if _cycle_amplitudes.size() < 2:
		return 0.0

	var first: Dictionary = _cycle_amplitudes[0]
	var last: Dictionary = _cycle_amplitudes[_cycle_amplitudes.size() - 1]
	var keys: Array = ["ANALYTICAL", "VALUE_DRIVEN", "RULING_GUIDE", "REVISIONIST", "GLOBAL"]
	var first_sum: float = 0.0
	var last_sum: float = 0.0
	for key in keys:
		first_sum += first.get(key, 0.0)
		last_sum += last.get(key, 0.0)
	return last_sum - first_sum

func get_cycle_amplitudes() -> Array:
	return _cycle_amplitudes.duplicate(true)

func reset() -> void:
	_cycle_amplitudes.clear()
	for key in _amplitude_sums:
		_amplitude_sums[key] = 0.0
	_current = {}
	_prev_etf_traded = ""

func _on_trading_opened(_time_limit: float) -> void:
	_current = {
		"cycle": SimulationManager.current_cycle,
		"time_to_decide": 0.0,
		"info_panel_opened": false,
		"info_panel_switches": 0,
		"etfs_checked": [],
		"headline_reread": false,
		"first_action": "HEADLINE",
		"trade_action": "HOLD",
		"etf_traded": "",
		"stop_loss_set": false,
		"perception_severity": SimulationManager._get_perception_severity(),
		"quantity_mode": "DOLLARS",
		"quantity": 0.0,
		"dollar_amount": 0.0,
		"portfolio_value_before": SimulationManager.get_portfolio_value(),
		"portfolio_value_after": 0.0
	}

func _on_trade_confirmed(trade_data: Dictionary) -> void:
	if _current.is_empty():
		return

	_current.merge(trade_data, true)
	_current["portfolio_value_after"] = SimulationManager.get_portfolio_value()

	var amplitudes: Dictionary = _score_cycle(_current)
	_cycle_amplitudes.append(amplitudes)
	for key in _amplitude_sums:
		_amplitude_sums[key] += amplitudes.get(key, 0.0)

	_prev_etf_traded = _current.get("etf_traded", "")
	_current = {}
	pathway_updated.emit(get_final_amplitudes())

func _score_cycle(cycle_data: Dictionary) -> Dictionary:
	var time_to_decide: float = cycle_data.get("time_to_decide", 99.0)
	var info_opened: bool = cycle_data.get("info_panel_opened", false)
	var info_switches: int = cycle_data.get("info_panel_switches", 0)
	var checked_etfs: Array = cycle_data.get("etfs_checked", [])
	var action: String = cycle_data.get("trade_action", "HOLD")
	var ticker: String = cycle_data.get("etf_traded", "")
	var reread_headline: bool = cycle_data.get("headline_reread", false)

	var broad_market_change: float = SimulationManager.ETF_CYCLE_CHANGES["CIQM"][
		SimulationManager.current_cycle - 1
	]
	var is_crash_cycle: bool = broad_market_change < 0.0
	var bought_during_crash: bool = action == "BUY" and is_crash_cycle

	var expedient: float = 1.0 if (time_to_decide < 5.0 and not info_opened) else 0.0
	var analytical: float = 1.0 if (info_opened and time_to_decide > 10.0) else 0.0

	var value_driven: float = 0.0
	if not ticker.is_empty() and ticker == _prev_etf_traded:
		value_driven = 1.0

	var ruling_guide: float = 1.0 if (
		info_switches >= 2 and checked_etfs.size() == SimulationManager.get_etf_order().size()
	) else 0.0

	var revisionist: float = 0.0
	if info_opened and reread_headline and bought_during_crash and cycle_data.get("first_action", "") == "INFO":
		revisionist = 1.0

	var macro_trade: bool = false
	if ticker in ["CIQE", "CIQD", "CIQS"]:
		macro_trade = SimulationManager.ETF_CYCLE_CHANGES[ticker][
			SimulationManager.current_cycle - 1
		] > 0.0
	var global_amplitude: float = 1.0 if (info_switches >= 3 and macro_trade) else 0.0

	return {
		"EXPEDIENT": expedient,
		"ANALYTICAL": analytical,
		"VALUE_DRIVEN": value_driven,
		"RULING_GUIDE": ruling_guide,
		"REVISIONIST": revisionist,
		"GLOBAL": global_amplitude
	}
