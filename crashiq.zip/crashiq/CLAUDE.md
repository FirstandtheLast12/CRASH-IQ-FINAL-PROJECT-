# CrashIQ — CLAUDE.md
# Geopolitical Crisis Trading Simulator · Behavioral Finance · Q-TPM Framework
# Godot 4.6 · Robinhood-style UI · Matrix Terminal Aesthetic

## Project status — what is already built and working
This project is partially complete. Do NOT rebuild things that already exist.
Read this section carefully before writing any code.

### ALREADY BUILT AND WORKING:
- StartScreen.tscn + StartScreen.gd — fully working with keyboard navigation
- MotivationCutscene.tscn + MotivationCutscene.gd — working with typewriter effect
- MarketIntroCutscene.tscn + MarketIntroCutscene.gd — working, shows 4 ETFs
- SimulationScreen.tscn + SimulationScreen.gd — partially working, needs trading UI rebuild
- ProfileScreen.tscn + ProfileScreen.gd — exists, needs testing
- autoloads/SimulationManager.gd — fully working state machine
- autoloads/BehaviorTracker.gd — fully working Q-TPM scoring
- autoloads/AudioManager.gd — exists
- scripts/CrashCycle.gd — working resource class
- scripts/HeadlinePopup.gd — working
- scripts/TradePanel.gd — exists but BUY/SELL not functional yet
- scripts/NewsTicker.gd — working
- scripts/ProfileScreen.gd — exists
- scripts/RadarChartController.gd — exists
- scripts/PLChartController.gd — exists

### WHAT NEEDS TO BE BUILT NEXT:
1. SimulationScreen trading UI — Robinhood-style layout (see section below)
2. Trading mechanics — buy/sell/hold execution with cash/portfolio updates
3. Bankruptcy condition — lose all money = game over
4. All 5 cycles advancing correctly with correct ETF price movements
5. Profile screen radar chart showing 6 TPM pathway amplitudes

---

## Academic framework
Implements Rodgers' Throughput Model (TPM) from:
"Quantum-enhanced throughput pathways: Integrating Rodgers' TPM with quantum
ethical frameworks for AI-driven cybersecurity" (Acta Psychologica, 2026).
Professor: Waymond Rodgers, University of Texas El Paso.

### TPM pipeline
  P (Perception)   → crash headline + chart movement shown to player
  I (Information)  → ETF price panels, portfolio value, cash balance
  J (Judgment)     → player considers which ETF to buy/sell/hold
  D (Decision)     → player confirms trade · quantum state collapses

### 6 TPM pathways
1. EXPEDIENT      P→D           Panic sells immediately, no info consulted
2. ANALYTICAL     I→J→D         Checks data first, deliberate decision
3. VALUE_DRIVEN   P→J→D         Consistent rule-follower across all cycles
4. RULING_GUIDE   P→I→J→D       Full deliberator, checks everything
5. REVISIONIST    I→P→D         Contrarian, buys during crashes
6. GLOBAL         I→P→J→D       Systems thinker, macro-aware

---

## Difficulty tiers
| Tier         | Starting Cash | Decision Timer |
|--------------|---------------|----------------|
| Student      | $500          | 30 seconds     |
| Young Pro    | $5,000        | 20 seconds     |
| Mid-career   | $25,000       | 15 seconds     |
| Veteran      | $100,000      | 10 seconds     |

---

## The 5 geopolitical cycles — Iran war escalation arc
FULLY ESCALATORY. No stabilization. No Saudi neutrality.

Cycle 1 — "Operation Epic Fury"
Headline: "BREAKING: US & Israel launch Operation Epic Fury — airstrikes hit Iranian command, navy, and nuclear sites"
CIQM: -8%   CIQE: +12%   CIQD: +15%   CIQS: +6%

Cycle 2 — "Strait Closed"
Headline: "BREAKING: Iran closes Strait of Hormuz — tankers under missile attack. 20% of global oil supply cut off"
CIQM: -15%   CIQE: +35%   CIQD: +8%   CIQS: +12%

Cycle 3 — "China Warns"
Headline: "BREAKING: China warns US to stand down — Iran strikes Saudi oil facilities. Kuwait and UAE infrastructure hit"
CIQM: -22%   CIQE: +48%   CIQD: +20%   CIQS: +18%

Cycle 4 — "Ground Invasion"
Headline: "BREAKING: US 82nd Airborne deployed — ground invasion begins to reopen Strait of Hormuz by force"
CIQM: -30%   CIQE: +60%   CIQD: +35%   CIQS: +22%

Cycle 5 — "Gulf Mined"
Headline: "BREAKING: Iran mines Persian Gulf — global recession declared. Chinese naval vessels enter conflict zone"
CIQM: -40%   CIQE: +75%   CIQD: +28%   CIQS: +30%

---

## The 4 tradeable ETFs
| Name                | Ticker | Start  | Behavior         |
|---------------------|--------|--------|------------------|
| CIQ Broad Market    | $CIQM  | $100   | Falls in crisis  |
| CIQ Energy Fund     | $CIQE  | $80    | Spikes in crisis |
| CIQ Defense Fund    | $CIQD  | $90    | Rises with war   |
| CIQ Safe Haven      | $CIQS  | $70    | Rises with fear  |

Player starts 100% cash. Fractional shares allowed.

---

## SimulationScreen — TARGET DESIGN (needs to be built)
Robinhood-style two column layout:

LEFT SIDE 70%:
- Top bar: CYCLE X/5 · red headline · timer · Cash · Portfolio
- 4 ETF tabs: [$CIQM] [$CIQE] [$CIQD] [$CIQS] — active tab green underline
- Active ETF: large name + large price (font 36) + % change colored + line chart
- Chart: green line if up, red if down, pulsing dot at current price
- Bottom: 3 mini chart thumbnails for other ETFs, clickable

RIGHT SIDE 30% — ORDER PANEL:
- Dark #0A0A0A background, green left border
- BUY / SELL tabs
- Buy in: [Shares] [Dollars] toggle
- Quantity input
- Market price (live)
- Estimated cost (updates as player types)
- Buying power = current cash
- Large green "Review Buy Order" button
- Yellow "HOLD" button

Review Order popup:
- ETF · Shares · Price · Total
- CONFIRM (green) · CANCEL (gray)
- On CONFIRM: execute trade, update SimulationManager cash/holdings, record BehaviorTracker

Trading rules:
- Cannot spend more than cash balance
- Cannot sell more than shares held
- Fractional shares OK
- Portfolio value = sum(shares * price) for all ETFs

Bankruptcy: cash + portfolio_value <= 1.0 → LIQUIDATED screen
Timer expiry: auto-HOLD, advance cycle
Cycle transition: 2 second overlay with next headline

---

## Visual theme — Matrix Terminal
- Background: #000000
- Primary text: #00FF41 matrix green
- Data/numbers: #FFFFFF white
- Headlines: #FFD700 yellow
- Falling lines: #FF0000 red
- Rising lines: #00FF41 green
- BUY: #00FF41  SELL: #FF4444  HOLD: #FFD700
- Font: monospace
- CRT scanlines at 10% opacity

---

## StartScreen — COMPLETE, DO NOT TOUCH
- LEFT/RIGHT arrows navigate, ENTER selects
- DEFCON TRADING SYSTEM v2.6 header
- CrashIQ: "Crash" yellow "IQ" green with blinking cursor
- Cards: Student=green, YoungPro=blue, MidCareer=yellow, Veteran=red
- Hover: border + background glow, scale 1.02
- News ticker yellow at bottom
- SYSTEM READY bottom right

## Game flow
1. StartScreen → ENTER to select difficulty
2. MotivationCutscene → SPACE to continue
3. MarketIntroCutscene → SPACE to continue
4. SimulationScreen → 5 cycles trading
5. ProfileScreen → behavioral profile + radar chart

---

## Godot 4.6 critical rules
- GDScript 2.0 only
- NO class_name on autoload scripts (causes "hides autoload singleton" error)
- Access autoloads by registered name only
- var not const for Arrays/Dictionaries
- visible=true/false inside VBoxContainer causes layout shift — use modulate.a
- RichTextLabel typewriter: use visible_characters property
- mouse_filter = MOUSE_FILTER_IGNORE on decorative child nodes
- Blinking elements must NOT be inside layout containers

## BehaviorTracker scoring per cycle
expedient:    time_to_decide < 5.0 AND NOT info_panel_opened
analytical:   info_panel_opened AND time_to_decide > 10.0
value_driven: same ETF as previous cycle
ruling_guide: info_panel_switches >= 2 AND all 4 ETFs checked
revisionist:  info_panel_opened BEFORE headline AND bought during crash
global:       info_panel_switches >= 3 AND macro-aware trade

## Remaining build sessions
Session 1: SimulationScreen layout (Robinhood UI, layout only, no logic)
Session 2: Trading mechanics (buy/sell execution, cash/portfolio)
Session 3: Cycle transitions + bankruptcy
Session 4: ProfileScreen radar chart
Session 5: Polish + videos + export

## Do NOT rebuild these — they work
StartScreen, MotivationCutscene, MarketIntroCutscene, all autoloads
