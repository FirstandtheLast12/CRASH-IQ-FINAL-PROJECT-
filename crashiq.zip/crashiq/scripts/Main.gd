extends Node

# ─── Scene registry ───────────────────────────────────────────────────────────
const SCENE_START:      String = "res://scenes/StartScreen.tscn"
const SCENE_MOTIVATION: String = "res://scenes/MotivationCutscene.tscn"
const SCENE_MARKET:     String = "res://scenes/MarketIntroCutscene.tscn"
const SCENE_SIM:        String = "res://scenes/SimulationScreen.tscn"
const SCENE_PROFILE:    String = "res://scenes/ProfileScreen.tscn"

var _current: Node = null

# ─── Lifecycle ───────────────────────────────────────────────────────────────
func _ready() -> void:
	DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_WINDOWED)
	DisplayServer.window_set_flag(DisplayServer.WINDOW_FLAG_BORDERLESS, false)
	DisplayServer.window_set_size(Vector2i(1280, 800))
	DisplayServer.window_set_position(Vector2i(100, 50))
	SimulationManager.simulation_complete.connect(_on_simulation_complete)
	_switch_to(SCENE_START)

# ─── Signal handlers ─────────────────────────────────────────────────────────
func _on_simulation_complete(_final_data: Dictionary) -> void:
	_switch_to(SCENE_PROFILE)

# ─── Public — called by screens and cutscenes ────────────────────────────────
func go_to_motivation() -> void:
	_switch_to(SCENE_MOTIVATION)

func go_to_market_intro() -> void:
	_switch_to(SCENE_MARKET)

func go_to_simulation() -> void:
	_switch_to(SCENE_SIM)

func go_to_start() -> void:
	SimulationManager.reset()
	BehaviorTracker.reset()
	_switch_to(SCENE_START)

# ─── Internal ─────────────────────────────────────────────────────────────────
func _switch_to(path: String) -> void:
	if _current != null:
		_current.queue_free()
		await _current.tree_exited
	var packed: PackedScene = load(path)
	_current = packed.instantiate()
	add_child(_current)
