extends Control

var input_locked = true
var animation_done = false

func _ready():
	_add_debug_label()
	create_rows()
	await get_tree().process_frame
	animate_rows()
	await get_tree().create_timer(0.2).timeout
	input_locked = false

func _input(event):
	if input_locked:
		return

	if event.is_action_pressed("ui_accept"):
		if not animation_done:
			skip_animation()
		else:
			get_tree().change_scene_to_file("res://scenes/SimulationScreen.tscn")

func create_rows():
	var y = 250
	var data = [
		["CIQM — BROAD MARKET","System-wide panic selling","Investors rapidly exit positions"],
		["CIQE — ENERGY","Oil supply disruption","Aggressive buying on oil spikes"],
		["CIQD — DEFENSE","Military escalation increases","Institutional inflows into defense"],
		["CIQS — SAFE HAVEN","Fear dominates markets","Flight to safety assets"],
		["CIQG — SHIPPING","Global trade disruption","Investors dump logistics exposure"]
	]

	for item in data:
		var row = Label.new()
		row.text = item[0] + "\nPRIMARY: " + item[1] + "\nBEHAVIOR: " + item[2]
		row.position = Vector2(200, y)
		row.modulate.a = 0
		add_child(row)
		y += 80

func animate_rows():
	var tween = create_tween()
	for child in get_children():
		if child is Label and child != get_child(0):
			tween.tween_property(child, "modulate:a", 1.0, 0.3)
	tween.finished.connect(func(): animation_done = true)

func skip_animation():
	for child in get_children():
		if child is Label:
			child.modulate.a = 1.0
	animation_done = true

func _add_debug_label():
	var label = Label.new()
	label.text = "ETFScreen.tscn | ETFScreen.gd"
	label.anchor_left = 1
	label.anchor_right = 1
	label.offset_left = -400
	label.offset_right = -10
	label.offset_top = 10
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	label.add_theme_font_size_override("font_size", 14)
	label.add_theme_color_override("font_color", Color(0,1,0))
	add_child(label)
