extends Control

@onready var _cycle_label: Label = %CycleLabel
@onready var _headline_label: Label = %HeadlineLabel
@onready var _timer_label: Label = %TimerLabel
@onready var decision_panel = get_node_or_null("%DecisionPanel")
@onready var cash_label: Label = %CashLabel
@onready var _portfolio_label: Label = %PortfolioLabel
@onready var _portfolio_cash_label: Label = $"OuterMargin/MainColumn/TopBar/TopBarMargin/TopBarContent/cash_label"
@onready var total_value_label: Label = $"OuterMargin/MainColumn/TopBar/TopBarMargin/TopBarContent/total_value_label"
@onready var pnl_label: Label = $"OuterMargin/MainColumn/TopBar/TopBarMargin/TopBarContent/pnl_label"
@onready var buying_power_label: Label = $"OuterMargin/MainColumn/BodyRow/TradePanel/TradeMargin/TradeContent/MetricsGrid/BuyingPowerValue"
@onready var position_label: Label = %"PositionLabel"
@onready var _timer_bar: ProgressBar = %TimerBar
@onready var _main_container: Control = $OuterMargin

@onready var _active_ticker_label: Label = %ActiveTickerLabel
@onready var _active_name_label: Label = %ActiveNameLabel
@onready var _active_price_label: Label = %ActivePriceLabel
@onready var _active_change_label: Label = %ActiveChangeLabel
@onready var _active_context_label: Label = %ActiveContextLabel
@onready var _hint_label: Label = %HintLabel
@onready var percent_label: Label = %ActiveChangeLabel

@onready var etf_tabs: Dictionary = {
	"CIQM": %TabCIQM,
	"CIQE": %TabCIQE,
	"CIQD": %TabCIQD,
	"CIQS": %TabCIQS,
	"CIQG": %TabCIQG
}

@onready var _charts: Dictionary = {
	"CIQM": %ChartCIQM,
	"CIQE": %ChartCIQE,
	"CIQD": %ChartCIQD,
	"CIQS": %ChartCIQS,
	"CIQG": %ChartCIQG
}

@onready var _summary_cards: Array = [
	{
		"button": %MiniCard1,
		"ticker": %MiniTicker1,
		"price": %MiniPrice1,
		"change": %MiniChange1
	},
	{
		"button": %MiniCard2,
		"ticker": %MiniTicker2,
		"price": %MiniPrice2,
		"change": %MiniChange2
	},
	{
		"button": %MiniCard3,
		"ticker": %MiniTicker3,
		"price": %MiniPrice3,
		"change": %MiniChange3
	},
	{
		"button": %MiniCard4,
		"ticker": %MiniTicker4,
		"price": %MiniPrice4,
		"change": %MiniChange4
	}
]

@onready var _trade_panel: TradePanel = %TradePanel
@onready var headline_popup = get_node_or_null("HeadlinePopup")

@onready var _info_panel: Control = %ETFInfoPanel
@onready var _info_ticker_label: Label = %InfoTickerLabel
@onready var _info_name_label: Label = %InfoNameLabel
@onready var _info_desc_label: Label = %InfoDescLabel
@onready var _info_context_label: Label = %InfoContextLabel
@onready var _info_modal_bg: ColorRect = %InfoModalBG

@onready var _transition_overlay: Control = %TransitionOverlay
@onready var _transition_cycle_label: Label = %TransitionCycleLabel
@onready var _transition_headline_label: Label = %TransitionHeadlineLabel

@onready var _liquidation_overlay: Control = %LiquidationOverlay
@onready var _liquidation_value_label: Label = %LiquidationValueLabel
@onready var _liquidation_cycle_label: Label = %LiquidationCycleLabel
@onready var _restart_button: Button = %RestartButton

var current_ticker: String = "CIQM"
var current_cycle = 1
var max_cycles = 5
var current_cash: float = 0.0
var input_locked = true
var market_open: bool = false
const TAB_YELLOW: Color = Color("ffd700")
const TAB_YELLOW_ACTIVE: Color = Color(1.0, 0.95, 0.45, 1.0)

func _ready() -> void:
	_add_debug_label()
	_apply_safe_area()
	SimulationManager.difficulty_set.connect(_on_difficulty_set)
	SimulationManager.cycle_started.connect(_on_cycle_started)
	SimulationManager.trading_opened.connect(_on_trading_opened)
	SimulationManager.trade_confirmed.connect(_on_trade_confirmed)
	SimulationManager.cycle_complete.connect(_on_cycle_complete)
	SimulationManager.liquidation_triggered.connect(_on_liquidation_triggered)
	SimulationManager.simulation_complete.connect(_on_simulation_complete)

	for ticker in etf_tabs:
		etf_tabs[ticker].pressed.connect(_on_etf_selected.bind(ticker))
	for ticker in _charts:
		_charts[ticker].chart_info_requested.connect(_on_chart_info_requested)
	for card in _summary_cards:
		card["button"].pressed.connect(_on_summary_card_pressed.bind(card["button"]))

	_info_modal_bg.gui_input.connect(_on_info_modal_gui_input)
	_restart_button.pressed.connect(_return_to_start)

	_transition_overlay.visible = false
	_liquidation_overlay.visible = false
	_info_panel.visible = false
	_timer_bar.visible = false
	_timer_bar.min_value = 0.0

	if not headline_popup:
		print("WARNING: HeadlinePopup node missing")
	current_cash = float(SimulationManager.get("current_cash")) if SimulationManager.get("current_cash") != null else SimulationManager.get_cash()
	if decision_panel and decision_panel.has_signal("decision_made"):
		decision_panel.decision_made.connect(_on_decision_made)
	if SimulationManager.has_signal("decision_processed"):
		SimulationManager.decision_processed.connect(_on_decision_result)

	current_ticker = "CIQM"
	_update_tab_highlight()
	_update_price_display()
	_update_chart()
	_update_cash_display()
	_update_portfolio_display()
	_refresh_all()

	if SimulationManager.current_state == SimulationManager.State.BRIEFING:
		SimulationManager.start_next_cycle()
	start_cycle()

func _apply_safe_area() -> void:
	var top_padding: float = 40.0
	if _main_container:
		_main_container.offset_top = top_padding

func _input(event: InputEvent) -> void:
	if input_locked:
		return
	if event.is_action_pressed("ui_accept"):
		print("SPACE pressed - phase toggle")
		next_cycle()
		_handle_space_press()

func start_cycle():
	input_locked = true
	if _cycle_label:
		_cycle_label.text = "CYCLE %d / %d" % [current_cycle, max_cycles]
	if headline_popup:
		headline_popup.visible = true
	await get_tree().create_timer(1.5).timeout
	input_locked = false

func next_cycle():
	current_cycle += 1
	if current_cycle > max_cycles:
		end_simulation()
		return
	start_cycle()

func end_simulation():
	get_tree().change_scene_to_file("res://scenes/ProfileScreen.tscn")

func _process(_delta: float) -> void:
	if SimulationManager.current_state == SimulationManager.State.TRADING:
		var remaining: float = SimulationManager.get_trading_time_remaining()
		var total: float = maxf(SimulationManager.decision_timer, 0.01)
		_timer_label.text = "%.1fs" % remaining
		_timer_label.modulate = Color("ff4444") if remaining <= 5.0 else Color(1.0, 1.0, 1.0, 0.92)
		_timer_bar.visible = true
		_timer_bar.max_value = total
		_timer_bar.value = remaining
		_timer_bar.modulate = Color("ff4444") if remaining / total < 0.3 else Color("00ff41")
	else:
		_timer_bar.visible = false
	var chart_controller: CandlestickChart = _charts.get(current_ticker)
	var history: Array = SimulationManager.get_price_history(current_ticker)
	if chart_controller and chart_controller.visible_points > 0 and chart_controller.visible_points <= history.size():
		var current_price: float = float(history[chart_controller.visible_points - 1])
		_active_price_label.text = "$%.2f" % current_price
	_refresh_top_bar()

func _on_difficulty_set(_tier: String, _cash: float, _timer: float) -> void:
	_refresh_all()

func _on_cycle_started(cycle_num: int, cycle_data: CrashCycle) -> void:
	market_open = false
	_transition_overlay.visible = false
	_liquidation_overlay.visible = false
	_cycle_label.text = "CYCLE %d / %d" % [cycle_num, SimulationManager.get_cycle_count()]
	_headline_label.text = cycle_data.headline
	_headline_label.modulate = Color("ffd700")
	_timer_label.text = "--"
	_refresh_all()

func _on_trading_opened(_time_limit: float) -> void:
	market_open = true
	_timer_bar.visible = true
	_trade_panel.select_etf(current_ticker)
	_refresh_all()

func _on_trade_confirmed(_trade_data: Dictionary) -> void:
	_update_cash_display()
	_update_position_display()
	_update_portfolio_display()
	_refresh_all()

func _on_cycle_complete(cycle_num: int, _portfolio_value: float) -> void:
	market_open = true
	_timer_label.text = "--"
	_refresh_all()

func _on_liquidation_triggered(final_data: Dictionary) -> void:
	market_open = false
	_transition_overlay.visible = false
	_liquidation_overlay.visible = true
	_liquidation_value_label.text = _format_currency(final_data.get("final_value", 0.0))
	_liquidation_cycle_label.text = "Liquidated in cycle %d" % int(final_data.get("liquidated_cycle", SimulationManager.current_cycle))

func _on_simulation_complete(_final_data: Dictionary) -> void:
	market_open = false
	_transition_overlay.visible = false

func _handle_space_press() -> void:
	if SimulationManager.current_state == SimulationManager.State.HEADLINE and not market_open:
		_start_market_phase()
	elif SimulationManager.current_state == SimulationManager.State.CYCLE_RESULT and market_open:
		_advance_to_next_cycle()

func _start_market_phase() -> void:
	market_open = true
	print("Market opened manually")
	start_trading_phase()

func _advance_to_next_cycle() -> void:
	market_open = false
	print("Advancing to next cycle")
	if SimulationManager.current_cycle < SimulationManager.get_cycle_count():
		show_cycle_transition()
		SimulationManager.start_next_cycle()

func start_trading_phase() -> void:
	if headline_popup:
		headline_popup.dismiss()
	else:
		print("HeadlinePopup not found")
	SimulationManager.open_trading_phase()

func show_cycle_transition() -> void:
	_transition_overlay.visible = false

func _on_etf_selected(ticker: String) -> void:
	current_ticker = ticker
	_trade_panel.select_etf(ticker)
	_update_tab_highlight()
	_update_price_display()
	_update_chart()
	_refresh_market_focus()

func _select_ticker(ticker: String) -> void:
	_on_etf_selected(ticker)

func _on_summary_card_pressed(button: Button) -> void:
	var ticker: String = String(button.get_meta("ticker", ""))
	if not ticker.is_empty():
		_select_ticker(ticker)

func _on_chart_info_requested(ticker: String) -> void:
	_select_ticker(ticker)
	_info_ticker_label.text = "$" + ticker
	_info_name_label.text = SimulationManager.get_etf_name(ticker)
	_info_desc_label.text = SimulationManager.get_etf_description(ticker)
	_info_context_label.text = SimulationManager.get_etf_context(ticker)
	_info_panel.visible = true

func _on_info_modal_gui_input(event: InputEvent) -> void:
	if event is InputEventMouseButton:
		var mouse_event: InputEventMouseButton = event
		if mouse_event.pressed and mouse_event.button_index == MOUSE_BUTTON_LEFT:
			_info_panel.visible = false
			BehaviorTracker.record_headline_viewed()

func _refresh_all() -> void:
	_refresh_top_bar()
	_refresh_market_focus()

func _refresh_top_bar() -> void:
	var current_cycle: int = SimulationManager.current_cycle
	_cycle_label.text = "CYCLE %d / %d" % [current_cycle, SimulationManager.get_cycle_count()]
	_update_cash_display()
	_portfolio_label.text = "Portfolio  %s" % _format_currency(SimulationManager.get_portfolio_value())
	_update_portfolio_display()

	var portfolio_value: float = SimulationManager.get_portfolio_value()
	if portfolio_value > SimulationManager.starting_cash:
		_portfolio_label.modulate = Color("00ff41")
	elif portfolio_value < SimulationManager.starting_cash:
		_portfolio_label.modulate = Color("ff4444")
	else:
		_portfolio_label.modulate = Color(1.0, 1.0, 1.0, 0.92)

	if SimulationManager.current_state != SimulationManager.State.TRADING:
		_timer_label.modulate = Color(1.0, 1.0, 1.0, 0.45)

func _update_cash_display() -> void:
	var cash: float = SimulationManager.get_cash()
	cash_label.text = "Cash: $%.2f" % cash
	_portfolio_cash_label.text = "Cash: $%.2f" % cash
	buying_power_label.text = "$%.2f" % cash

func update_cash_display() -> void:
	cash_label.text = "$" + str(round(current_cash))

func _update_portfolio_display() -> void:
	var cash: float = SimulationManager.get_cash()
	var portfolio_value: float = SimulationManager.get_portfolio_value()
	var total: float = cash + portfolio_value

	var pnl: float = total - SimulationManager.starting_cash

	cash_label.text = "Cash: $%.2f" % cash
	total_value_label.text = "Total: $%.2f" % total

	if pnl >= 0:
		pnl_label.modulate = Color(0, 1, 0)
	else:
		pnl_label.modulate = Color(1, 0, 0)

	pnl_label.text = "P/L: $%.2f" % pnl

func _update_position_display() -> void:
	var shares: float = SimulationManager.get_shares(current_ticker)
	position_label.text = "Position %.4f shares" % shares

func _update_tab_highlight() -> void:
	for ticker in etf_tabs:
		var btn: Button = etf_tabs[ticker]
		if ticker == current_ticker:
			btn.modulate = Color(1, 0.85, 0.2)
		else:
			btn.modulate = Color(0.5, 0.5, 0.5)

func _refresh_market_focus() -> void:
	_update_tab_highlight()
	for ticker in etf_tabs:
		var is_active: bool = ticker == current_ticker
		var button: Button = etf_tabs[ticker]
		button.add_theme_color_override("font_color", TAB_YELLOW)
		button.add_theme_color_override("font_focus_color", TAB_YELLOW_ACTIVE)
		button.add_theme_color_override("font_hover_color", TAB_YELLOW_ACTIVE)
		button.add_theme_color_override("font_pressed_color", TAB_YELLOW_ACTIVE)

	for ticker in _charts:
		_charts[ticker].visible = ticker == current_ticker
		_charts[ticker].set_chart_focused(ticker == current_ticker)

	_active_ticker_label.text = "$" + current_ticker
	_active_name_label.text = SimulationManager.get_etf_name(current_ticker)
	var price: float = SimulationManager.get_price(current_ticker)
	_active_price_label.text = "$%.2f" % price

	var change: float = SimulationManager.get_cycle_change(current_ticker) * 100.0
	var sign: String = "+" if change >= 0.0 else ""
	_active_change_label.text = "%s%.2f%% this cycle" % [sign, change]
	_active_change_label.modulate = Color("00ff41") if change >= 0.0 else Color("ff4444")
	_update_etf_explanation(current_ticker)
	_hint_label.text = _get_hint(current_ticker)
	_update_position_display()

	_refresh_summary_cards()
	_trade_panel.select_etf(current_ticker)

func _update_price_display() -> void:
	var price: float = SimulationManager.get_price(current_ticker)
	_active_price_label.text = "$%.2f" % price
	var change: float = SimulationManager.get_cycle_change(current_ticker) * 100.0
	percent_label.text = "%.2f%% this cycle" % change
	if change < 0.0:
		percent_label.modulate = Color(1, 0.2, 0.2)
	else:
		percent_label.modulate = Color(0, 1, 0)
	percent_label.modulate.a = 1.0

func _update_chart() -> void:
	var raw_history: Array = SimulationManager.get_price_history(current_ticker)
	print(typeof(raw_history), raw_history)
	var price_history: Array[float] = []
	for value in raw_history:
		price_history.append(float(value))
	print("Chart data:", price_history)
	if price_history.is_empty():
		print("No price data for chart")
		return
	if price_history.size() < 2:
		price_history = [price_history[0], price_history[0]]

	var chart_controller: CandlestickChart = _charts.get(current_ticker)
	if chart_controller:
		chart_controller.set_data(price_history)
		chart_controller.queue_redraw()

func _update_etf_explanation(ticker: String) -> void:
	var text: String = ""

	match ticker:
		"CIQM":
			text = "PRIMARY EFFECT: System-wide panic selling\nINVESTOR BEHAVIOR: Investors rapidly exit positions"
		"CIQE":
			text = "PRIMARY EFFECT: Oil supply disruption\nINVESTOR BEHAVIOR: Aggressive buying on oil spikes"
		"CIQD":
			text = "PRIMARY EFFECT: Military escalation increases\nINVESTOR BEHAVIOR: Institutional inflows into defense"
		"CIQS":
			text = "PRIMARY EFFECT: Fear dominates markets\nINVESTOR BEHAVIOR: Flight to safety assets"
		"CIQG":
			text = "PRIMARY EFFECT: Global trade disruption\nINVESTOR BEHAVIOR: Investors dump logistics exposure"
		_:
			text = SimulationManager.get_etf_context(ticker)

	_active_context_label.text = text

func _get_hint(ticker: String) -> String:
	match ticker:
		"CIQM":
			return "Most players SELL during panic"
		"CIQE":
			return "Many BUY energy in crises"
		"CIQD":
			return "Defense often rises in war"
		"CIQS":
			return "Safe haven = lower risk"
		"CIQG":
			return "Shipping weak in conflict"
		_:
			return ""

func _refresh_summary_cards() -> void:
	var other_tickers: Array[String] = []
	for ticker in SimulationManager.get_etf_order():
		if ticker != current_ticker:
			other_tickers.append(ticker)

	for index in range(_summary_cards.size()):
		var card: Dictionary = _summary_cards[index]
		if index >= other_tickers.size():
			card["button"].visible = false
			card["button"].set_meta("ticker", "")
			continue

		var ticker: String = other_tickers[index]
		card["button"].visible = true
		card["button"].set_meta("ticker", ticker)
		card["ticker"].text = "$" + ticker
		var price: float = SimulationManager.get_price(ticker)
		card["price"].text = "$%.2f" % price
		var change: float = SimulationManager.get_cycle_change(ticker) * 100.0
		var sign: String = "+" if change >= 0.0 else ""
		card["change"].text = "%s%.2f%%" % [sign, change]
		card["change"].modulate = Color("00ff41") if change >= 0.0 else Color("ff4444")

func _return_to_start() -> void:
	get_tree().get_root().get_node("Main").go_to_start()

func _on_decision_made(choice) -> void:
	SimulationManager.process_decision(choice)

func _on_decision_result(data) -> void:
	current_cash = data["cash"]
	update_cash_display()
	show_feedback(data["delta"])

func show_feedback(delta) -> void:
	var label: Label = Label.new()
	if delta >= 0:
		label.text = "+$" + str(round(delta))
		label.modulate = Color.GREEN
	else:
		label.text = "-$" + str(round(abs(delta)))
		label.modulate = Color.RED
	add_child(label)
	label.position = Vector2(500, 200)
	var tween: Tween = create_tween()
	tween.tween_property(label, "position:y", label.position.y - 80, 0.6)
	tween.tween_property(label, "modulate:a", 0, 0.6)

func show_final_profile() -> void:
	var result = SimulationManager.get_primary_profile()
	print("FINAL TYPE: ", result)

func _format_currency(value: float) -> String:
	return "$%s" % _format_number(value)

func _format_number(value: float) -> String:
	var raw: String = "%.2f" % value
	var parts: PackedStringArray = raw.split(".")
	var integer_part: String = parts[0]
	var prefix: String = ""
	if integer_part.begins_with("-"):
		prefix = "-"
		integer_part = integer_part.substr(1)
	var result: String = ""
	var count: int = 0
	for index in range(integer_part.length() - 1, -1, -1):
		if count > 0 and count % 3 == 0:
			result = "," + result
		result = integer_part[index] + result
		count += 1
	return prefix + result + "." + parts[1]

func _add_debug_label():
	var label = Label.new()
	label.text = "SimulationScreen.tscn | SimulationScreen.gd"
	label.anchor_left = 1
	label.anchor_right = 1
	label.offset_left = -400
	label.offset_right = -10
	label.offset_top = 10
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	label.add_theme_font_size_override("font_size", 14)
	label.add_theme_color_override("font_color", Color(0,1,0))
	add_child(label)
