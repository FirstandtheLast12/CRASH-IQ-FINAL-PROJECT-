class_name MarketIntroCutscene
extends Control

var input_locked = true

var text_label : RichTextLabel
var continue_label : Label

var typing_speed := 0.025
var blink_on := false

var full_text := "[center]" + \
"[color=yellow][b]ETF'S BEING TRADED[/b][/color]\n\n" + \
"[color=gray]CLASSIFIED MARKET BRIEFING[/color]" + \
"[/center]"

func _ready():
	_add_debug_label()

	text_label = RichTextLabel.new()
	add_child(text_label)

	text_label.bbcode_enabled = true
	text_label.text = full_text
	text_label.visible_characters = 0
	text_label.anchor_left = 0.5
	text_label.anchor_right = 0.5
	text_label.anchor_top = 0.5
	text_label.anchor_bottom = 0.5
	text_label.offset_left = -500
	text_label.offset_right = 500
	text_label.offset_top = -120
	text_label.offset_bottom = 120
	text_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER

	continue_label = Label.new()
	add_child(continue_label)

	continue_label.text = "PRESS SPACE TO CONTINUE"
	continue_label.visible = false
	continue_label.anchor_left = 0.5
	continue_label.anchor_right = 0.5
	continue_label.anchor_top = 1
	continue_label.anchor_bottom = 1
	continue_label.offset_left = -200
	continue_label.offset_right = 200
	continue_label.offset_top = -60
	continue_label.offset_bottom = -20
	continue_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	continue_label.add_theme_color_override("font_color", Color(0,1,0))

	await type_text()

	input_locked = false

	start_blink()

func type_text():
	var total = text_label.get_total_character_count()

	for i in range(total):
		text_label.visible_characters = i
		await get_tree().create_timer(typing_speed).timeout

	text_label.visible_characters = total

func start_blink():
	blink_on = true
	blink_loop()

func blink_loop():
	while blink_on:
		continue_label.visible = !continue_label.visible
		await get_tree().create_timer(0.7).timeout

func _input(event):
	if input_locked:
		return

	if event.is_action_pressed("ui_accept"):
		blink_on = false
		get_tree().change_scene_to_file("res://scenes/ETFScreen.tscn")

func _add_debug_label():
	var label = Label.new()
	label.text = "MarketIntroCutscene.tscn | MarketIntroCutscene.gd"
	label.anchor_left = 1
	label.anchor_right = 1
	label.offset_left = -400
	label.offset_right = -10
	label.offset_top = 10
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	label.add_theme_font_size_override("font_size", 14)
	label.add_theme_color_override("font_color", Color(0,1,0))
	add_child(label)
