class_name MotivationCutscene
extends Control

var input_locked = true

var text_label : RichTextLabel
var continue_label : Label

var full_text := "[center]" + \
"[color=yellow][b]The US just launched airstrikes on Iran.[/b][/color]\n\n" + \
"[color=yellow][b]The Strait of Hormuz is closing.[/b][/color]\n\n" + \
"[color=yellow][b]You have [/b][/color][color=red][b]$500[/b][/color][color=yellow][b] in your Robinhood account and one thought:[/b][/color]\n\n" + \
"[color=yellow][b]If there is going to be a war - you are going to profit from it.[/b][/color]" + \
"[/center]"

var typing_speed := 0.025
var fade_visible := true

func _ready():
	_add_debug_label()

	text_label = RichTextLabel.new()
	add_child(text_label)

	text_label.bbcode_enabled = true
	text_label.text = full_text
	text_label.visible_characters = 0
	text_label.anchor_left = 0.5
	text_label.anchor_right = 0.5
	text_label.anchor_top = 0.5
	text_label.anchor_bottom = 0.5
	text_label.offset_left = -500
	text_label.offset_right = 500
	text_label.offset_top = -150
	text_label.offset_bottom = 150
	text_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER

	continue_label = Label.new()
	add_child(continue_label)

	continue_label.text = "PRESS SPACE TO CONTINUE"
	continue_label.anchor_left = 0.5
	continue_label.anchor_right = 0.5
	continue_label.anchor_top = 1
	continue_label.anchor_bottom = 1
	continue_label.offset_left = -200
	continue_label.offset_right = 200
	continue_label.offset_top = -60
	continue_label.offset_bottom = -20
	continue_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	continue_label.add_theme_color_override("font_color", Color(0,1,0))
	continue_label.modulate.a = 0.0

	await type_text()

	start_blink()

	input_locked = false

func type_text():
	var total = text_label.get_total_character_count()

	for i in range(total):
		text_label.visible_characters = i
		await get_tree().create_timer(typing_speed).timeout

	text_label.visible_characters = total

func start_blink():
	blink_loop()

func blink_loop():
	while true:
		if fade_visible:
			continue_label.modulate.a = 1.0
		else:
			continue_label.modulate.a = 0.0

		fade_visible = !fade_visible
		await get_tree().create_timer(0.7).timeout

func _input(event):
	if input_locked:
		return

	if event.is_action_pressed("ui_accept"):
		get_tree().change_scene_to_file("res://scenes/MarketIntroCutscene.tscn")

func _add_debug_label():
	var label = Label.new()
	label.text = "MotivationCutscene.tscn | MotivationCutscene.gd"
	label.anchor_left = 1
	label.anchor_right = 1
	label.offset_left = -400
	label.offset_right = -10
	label.offset_top = 10
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	label.add_theme_font_size_override("font_size", 14)
	label.add_theme_color_override("font_color", Color(0,1,0))
	add_child(label)
