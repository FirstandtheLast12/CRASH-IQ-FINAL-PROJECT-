class_name HeadlinePopup
extends Control

@onready var _overlay: ColorRect = %PopupOverlay
@onready var _breaking: Label = %BreakingLabel
@onready var _headline: Label = %HeadlineText
@onready var _subtext: Label = %SubtextText
@onready var _countdown: Label = %CountdownLabel

var _running: bool = false

func _ready() -> void:
	visible = false
	SimulationManager.cycle_started.connect(_on_cycle_started)

func _on_cycle_started(_cycle_num: int, cycle_data: CrashCycle) -> void:
	if _running:
		return
	_show_manual_intro(cycle_data.headline, cycle_data.subtext)

func _show_manual_intro(headline: String, subtext: String) -> void:
	_running = true
	visible = true
	modulate.a = 1.0
	_breaking.visible = true
	_breaking.modulate.a = 1.0
	_headline.visible = true
	_headline.text = headline
	_subtext.visible = true
	_subtext.modulate.a = 1.0
	_subtext.text = subtext
	_countdown.visible = true
	_countdown.text = "PRESS SPACE TO OPEN MARKETS"

func dismiss() -> void:
	visible = false
	_running = false
