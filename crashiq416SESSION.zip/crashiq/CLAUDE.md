# CrashIQ — CLAUDE.md
# Geopolitical Crisis Trading Simulator · Behavioral Finance · Q-TPM Framework
# Godot 4.6 · Robinhood-style UI · Matrix Terminal Aesthetic

## Project status — what is already built and working
This project is substantially complete through Session 2. Do NOT rebuild things that already exist.
Read this section carefully before writing any code.

### COMPLETE — DO NOT TOUCH:
- StartScreen.tscn + StartScreen.gd — fully working with keyboard navigation
- MotivationCutscene.tscn + MotivationCutscene.gd — working with typewriter effect
- MarketIntroCutscene.tscn + MarketIntroCutscene.gd — working, shows all 5 ETFs
- autoloads/SimulationManager.gd — full state machine, all 5 cycles, pricing, bankruptcy
- autoloads/BehaviorTracker.gd — full Q-TPM scoring, 6 pathways, amplitudes, metrics
- autoloads/AudioManager.gd — stub (no-op), safe to call
- autoloads/GlobalInput.gd — ESC handler
- scripts/CrashCycle.gd — working resource class
- scripts/TradePanel.gd — FULLY WORKING: BUY/SELL/HOLD, review popup, validation, fractional shares
- scripts/NewsTicker.gd — working
- scripts/RadarChartControl.gd — working, 6-axis spider chart with custom _draw()
- scripts/PLChartControl.gd — working, P&L line chart with reference line
- scripts/TPMResultsScreen.gd — working, shows classification + decision log
- scripts/ProfileScreen.gd — working, radar + P&L + pathway breakdown + learning delta

### WORKING BUT MAY NEED POLISH:
- SimulationScreen.tscn + SimulationScreen.gd — layout complete, trading works,
  cycle advance works, headline animation works, liquidation overlay works
- scripts/CandlestickChart.gd — chart rendering complete:
  - Historical line chart with animated reveal (set_data + visible_points)
  - Pulsing dot at latest price point
  - Cycle boundary vertical marker lines (C1–C4) with price labels
  - Open price dashed reference line (uses get_cycle_open_price)
  - Price label in SimulationScreen flickers during TRADING (display noise only, not data)

### LEGACY / UNUSED (do not modify or integrate):
- autoloads/DecisionManager.gd — old prototype, not connected to anything
- scripts/DecisionPanel.gd — legacy scene, not used
- scripts/ETFScreen.gd — legacy, not used
- scenes/DecisionPanel.tscn — legacy
- scenes/ETFScreen.tscn — legacy

### WHAT REMAINS:
1. Session 3: Cycle transition polish + bankruptcy edge case review
2. Session 4: ProfileScreen visual pass (radar tuning if needed)
3. Session 5: AudioManager full implementation + CRT scanlines + export

---

## Academic framework
Implements Rodgers' Throughput Model (TPM) from:
"Quantum-enhanced throughput pathways: Integrating Rodgers' TPM with quantum
ethical frameworks for AI-driven cybersecurity" (Acta Psychologica, 2026).
Professor: Waymond Rodgers, University of Texas El Paso.

### TPM pipeline
  P (Perception)   → crash headline + chart movement shown to player
  I (Information)  → ETF price panels, portfolio value, cash balance
  J (Judgment)     → player considers which ETF to buy/sell/hold
  D (Decision)     → player confirms trade · quantum state collapses

### 6 TPM pathways
1. EXPEDIENT      P→D           Panic sells immediately, no info consulted
2. ANALYTICAL     I→J→D         Checks data first, deliberate decision
3. VALUE_DRIVEN   P→J→D         Consistent rule-follower across all cycles
4. RULING_GUIDE   P→I→J→D       Full deliberator, checks everything
5. REVISIONIST    I→P→D         Contrarian, buys during crashes
6. GLOBAL         I→P→J→D       Systems thinker, macro-aware

---

## Difficulty tiers
| Tier         | Starting Cash | Decision Timer |
|--------------|---------------|----------------|
| Student      | $500          | 30 seconds     |
| Young Pro    | $5,000        | 20 seconds     |
| Mid-career   | $25,000       | 15 seconds     |
| Veteran      | $100,000      | 10 seconds     |

---

## The 5 geopolitical cycles — Iran war escalation arc
FULLY ESCALATORY. No stabilization. No Saudi neutrality.
NOTE: Cycle changes in code differ slightly from original design doc — these are the ACTUAL values in SimulationManager.gd:

Cycle 1 — "Operation Epic Fury"
Headline: "BREAKING: US and Israel launch Operation Epic Fury — airstrikes hit Iranian command, navy, and nuclear sites"
CIQM: -8%   CIQE: +12%   CIQD: +15%   CIQS: +6%   CIQG: -5%

Cycle 2 — "Strait Closed"
Headline: "BREAKING: Iran closes Strait of Hormuz — tankers under missile attack. 20% of global oil supply cut off"
CIQM: -15%   CIQE: +35%   CIQD: -8%   CIQS: +12%   CIQG: -22%
(CIQD reversal in C2 is intentional — defense profit-taking between shock waves)

Cycle 3 — "China Warns"
Headline: "BREAKING: China warns US to stand down — Iran strikes Saudi oil facilities. Kuwait and UAE infrastructure hit"
CIQM: -22%   CIQE: +48%   CIQD: +20%   CIQS: +18%   CIQG: -25%

Cycle 4 — "Ground Invasion"
Headline: "BREAKING: US 82nd Airborne deployed — ground invasion begins to reopen Strait of Hormuz by force"
CIQM: -30%   CIQE: +60%   CIQD: +35%   CIQS: +22%   CIQG: -32%

Cycle 5 — "Gulf Mined"
Headline: "BREAKING: Iran mines Persian Gulf — global recession declared. Chinese naval vessels enter conflict zone"
CIQM: -40%   CIQE: +75%   CIQD: +28%   CIQS: +30%   CIQG: -38%
(CIQE C4 is -8% / C5 is +40% — energy reverses on invasion, then spikes again at recession)

---

## The 5 tradeable ETFs
| Name                  | Ticker | Start  | Behavior                       |
|-----------------------|--------|--------|--------------------------------|
| CIQ Broad Market      | $CIQM  | $100   | Falls throughout crisis        |
| CIQ Energy Fund       | $CIQE  | $80    | Spikes on oil, reversal in C4  |
| CIQ Defense Fund      | $CIQD  | $90    | Rises with war, dips in C2     |
| CIQ Safe Haven        | $CIQS  | $70    | Steady rise with fear          |
| CIQ Global Shipping   | $CIQG  | $60    | Collapses, brief pop in C4     |

NOTE: CIQG was added after the original 4-ETF design. It is fully active in code.
Player starts 100% cash. Fractional shares allowed.

---

## SimulationScreen — CURRENT DESIGN (as built)
Robinhood-style two column layout — WORKING:

LEFT SIDE (~70%):
- Top bar: CYCLE X/5 · headline label · timer (countdown) · Cash · Portfolio
- TimerBar: ProgressBar under top bar, green/red based on time remaining
- 5 ETF tabs: [$CIQM] [$CIQE] [$CIQD] [$CIQS] [$CIQG] — active tab highlighted
- Active ETF header: large ticker + large price (flickers during TRADING) + % change
- ActiveContextLabel: ETF behavior description (RichTextLabel)
- CandlestickChart: line chart, pulsing dot, cycle markers, open price dashed line
- TimeRangeRow: [1D][1W][1M][3M][YTD][1Y][5Y][MAX] buttons (cosmetic only)
- MiniCardRow: 4 mini cards for non-active ETFs (clickable, switches active tab)

RIGHT SIDE (~30%) — TradePanel:
- BUY / SELL action tabs
- DOLLARS / SHARES quantity mode toggle
- Quantity LineEdit (pulses yellow until player types)
- Market price display, estimated cost, buying power (cash balance)
- "Review [BUY/SELL] Order" button → ReviewPopup
- Yellow HOLD button (submits hold immediately, no review)

ReviewPopup (inline modal):
- ETF name · shares · price · total
- CONFIRM (green) → SimulationManager.confirm_trade()
- CANCEL (gray) → closes popup

HeadlinePopup overlay (per cycle):
- "BREAKING" pulsing red label
- Typewriter headline text (RichTextLabel)
- Subtext label (fades in after headline)
- "SPACE to trade" blinking countdown
- SPACE skips animation (DEV_ALLOW_HEADLINE_SKIP = true)

ETFInfoPanel (modal drawer, click chart or context area to open):
- Ticker, name, description, context text
- BehaviorTracker.record_info_panel_opened() called on open
- Click InfoModalBG to close

---

## CandlestickChart — key behavior
- Chart data is STATIC after set_data() is called. No live mutation of chart data.
- visible_points animates the reveal from left to right (20 pts/second)
- Price label in SimulationScreen flickers independently (±1.2% noise on real price, every 0.8s)
  This is display-only — does NOT affect chart data or SimulationManager state
- Cycle boundary lines: drawn at every 40-point interval (C1 marker at index 40, etc.)
  Color: Color("ff3b30") at 0.75 alpha · Lines constrained top (chart_top + 30) and bottom (chart_height - 28)
  Labels: "C1"–"C4" + price at boundary, bottom-anchored
- Open price reference: dashed horizontal line at SimulationManager.get_cycle_open_price(ticker)
  Color: color_reference = Color(1,1,1,0.30) · Label "$X.XX" at right edge

---

## Visual theme — Matrix Terminal
- Background: #000000
- Primary text: #00FF41 matrix green
- Data/numbers: #FFFFFF white
- Headlines: #FFD700 yellow
- Falling lines: #FF0000 red
- Rising lines: #00FF41 green
- BUY: #00FF41  SELL: #FF4444  HOLD: #FFD700
- Font: monospace
- CRT scanlines at 10% opacity (Session 5)

---

## Game flow
1. StartScreen → ENTER to select difficulty
2. MotivationCutscene → SPACE to continue
3. MarketIntroCutscene → SPACE to continue
4. SimulationScreen → 5 cycles trading
5. TPMResultsScreen → classification + decision log + CONTINUE
6. ProfileScreen → behavioral profile + radar chart + P&L chart + PLAY AGAIN

---

## Godot 4.6 critical rules
- GDScript 2.0 only
- NO class_name on autoload scripts (causes "hides autoload singleton" error)
- Access autoloads by registered name only
- var not const for Arrays/Dictionaries
- visible=true/false inside VBoxContainer causes layout shift — use modulate.a
- RichTextLabel typewriter: use visible_characters property
- mouse_filter = MOUSE_FILTER_IGNORE on decorative child nodes
- Blinking elements must NOT be inside layout containers
- Tab-only indentation — a single space character before a tab causes a parse error
- Do NOT redeclare a variable in an inner block if it is already declared in the same function scope
  (causes "Parser Error: Could not parse global class" — variable shadowing is not allowed in GDScript)

## BehaviorTracker scoring per cycle
expedient:    time_to_decide < 5.0 AND NOT info_panel_opened           (0.5 if time < 8.0)
analytical:   info_panel_opened AND time_to_decide > 10.0              (0.5 if time > 5.0)
value_driven: same ETF as previous cycle AND action != HOLD
ruling_guide: info_panel_switches >= 2 AND all ETFs checked (5 now)
revisionist:  first_action == INFO AND reread_headline AND bought during crash
global:       info_panel_switches >= 3 AND traded a macro ETF that moved up this cycle

## Remaining build sessions
Session 3: Cycle transition polish + bankruptcy edge case review
Session 4: ProfileScreen/radar visual pass (if needed)
Session 5: AudioManager full implementation + CRT scanlines + export

## Do NOT rebuild these — they work
StartScreen, MotivationCutscene, MarketIntroCutscene, all autoloads,
TradePanel, CandlestickChart, TPMResultsScreen, ProfileScreen, RadarChartControl, PLChartControl

## SimulationManager.gd — public API reference
get_cycle_open_price(ticker) → float   open price snapshotted at start of current cycle
get_cycle_change(ticker) → float       fractional change for current cycle (e.g. -0.08)
get_price(ticker) → float              current ETF price
get_price_history(ticker) → Array      all historical price points (grows each cycle)
get_portfolio_value() → float          cash + sum(shares * price)
get_cash() → float
get_shares(ticker) → float
get_cycle_count() → int                always 5
get_etf_order() → Array[String]        ["CIQM","CIQE","CIQD","CIQS","CIQG"]
validate_trade(trade_data) → Dict      {ok, message, shares, estimated_total}
confirm_trade(trade_data) → bool       executes trade, advances state, may trigger liquidation
